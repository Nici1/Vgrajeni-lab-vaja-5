#include <asf.h>
#include <delay.h>
#include <test-more.h>
#include <ioport.h>
#include <lcd.h>
#include <adc.h>
#include <tc.h>


#ifdef __cplusplus
extern "C" {
#endif
#define LED_L_PORT PIOB
#define LED_L_PIN PIO_PB27

#define L1_IDX PIO_PC26_IDX

int stevec = 0;

int main (void)
{



    /* sets the processor clock according to conf_clock.h definitions */
    sysclk_init();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/

    init_btn_leds();
    /* ioport_init();
     ioport_enable_pin(L1_IDX);
     ioport_set_pin_dir(L1_IDX ,IOPORT_DIR_OUTPUT);
     ioport_set_pin_level(L1_IDX ,1);
     delay_ms(500);
     ioport_set_pin_level(L1_IDX ,0); */


    ioport_init();








    // init timer
    //systemcoreclock


    /********************* Main loop     ***************************/










    //to so procenti




    while(1)
    {

        int btn;
        btn = get_btn_press();



        if ((btn & (1<<0) )!= 0)
        {
            stevec += 1;
        }


        if ((btn & (1<<1) )!= 0)
        {
            stevec -= 1;
        }


        if(stevec<=0)
            stevec=0;

    lcd_init();
    int konec1 = sprintf(lcd_string,"VAJA 5");
    lcd_string[konec1] =' ';
    int konec = sprintf(lcd_string+16,"Stevec=%lu",stevec);
    lcd_string[konec+16] =' ';
    lcd_driver();



    }

    /******************** varnost     ***************************/
    while(1)
    {


    }

}





#ifdef __cplusplus
}
#endif
