#ifndef TEST_MORE_H_INCLUDED
#define TEST_MORE_H_INCLUDED
# include <stdint.h>


void init_btn_leds(void);
int get_btn_state(void);
int get_btn_press(void);

#define L1_IDX PIO_PC26_IDX
#define Tip1_IDX PIO_PC21_IDX


#define L2_IDX PIO_PC25_IDX
#define Tip2_IDX PIO_PC29_IDX


#define L3_IDX PIO_PC24_IDX
#define Tip3_IDX PIO_PD7_IDX


#define L4_IDX PIO_PC23_IDX
#define Tip4_IDX PIO_PD8_IDX

#endif
 // TEST-MORE_H_INCLUDED
