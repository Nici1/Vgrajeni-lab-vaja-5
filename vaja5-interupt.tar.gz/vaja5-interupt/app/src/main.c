#include <asf.h>
#include <delay.h>
#include <test-more.h>
#include <ioport.h>
#include <lcd.h>
#include <adc.h>
#include <tc.h>


#ifdef __cplusplus
extern "C" {
#endif
#define LED_L_PORT PIOB
#define LED_L_PIN PIO_PB27

#define L1_IDX PIO_PC26_IDX

#define Tip1 PIO_PC21
#define Tip2 PIO_PC29

int stevec = 0;

int main (void)
{



    /* sets the processor clock according to conf_clock.h definitions */
    sysclk_init();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/

   init_btn_leds();
    /* ioport_init();
     ioport_enable_pin(L1_IDX);
     ioport_set_pin_dir(L1_IDX ,IOPORT_DIR_OUTPUT);
     ioport_set_pin_level(L1_IDX ,1);
     delay_ms(500);
     ioport_set_pin_level(L1_IDX ,0); */

    lcd_init();

     NVIC_EnableIRQ(PIOC_IRQn);
     pio_enable_interrupt(PIOC, Tip1 | Tip2);
     pio_configure_interrupt(PIOC, Tip1 | Tip2, PIO_IT_FALL_EDGE);
     pio_set_debounce_filter(PIOC, Tip1 | Tip2,100);


    //ioport_init();



    // init timer
    //systemcoreclock


    /********************* Main loop     ***************************/





    //to so procenti




    while(1)
    {


        if(stevec<=0)
            stevec=0;
        //if(stevec>=100000)
            //stevec=100000;


    int konec1 = sprintf(lcd_string,"VAJA 5");
    lcd_string[konec1] =' ';
    int konec = sprintf(lcd_string+16,"Stevec=%lu",stevec);
    lcd_string[konec+16] =' ';

    //lcd_string[konec+19]=' ';
    lcd_driver();

    }

    /******************** varnost     ***************************/
    while(1)
    {


    }

}

void PIOC_Handler(void)
{
    //ISR, prekinitvena rutina

    /** ce je led on => ugasni, nastavi RC na n_off**/
    /** ce LED off => prizgi, nastavi RC na n_on **/
    /** brisi IRQ zahtevo => beri status **/


    uint32_t status = pio_get_interrupt_status(PIOC);


    if(status & Tip1){
    stevec++;
    }
    if(status & Tip2){
    stevec--;
    }



    /* if( NVIC_GetPendingIRQ(TC0_IRQn) ){
         //code too slow
     }
     */

}




#ifdef __cplusplus
}
#endif
